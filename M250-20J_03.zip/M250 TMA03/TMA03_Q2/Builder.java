import java.util.*;

/**
 * The class Builder is used to hold data about the builder's 
 * on site  contractors, and their contact details and trade. 
 * 
 * @author 
 * @version  
 */
 public class Builder
 {
   /**
     * Constructor for objects of class Builder
     */
     public Builder()
     {
        super();
     }
   
}
